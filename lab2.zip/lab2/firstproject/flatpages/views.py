from django.shortcuts import render
from django.shortcuts import render
from django import template
from django.http import HttpResponse
def home(request):
 return render(request, 'templates/index.html')
# Create your views here.
def hello(request):
    return HttpResponse(u'Hello world!', content_type="text/plain")